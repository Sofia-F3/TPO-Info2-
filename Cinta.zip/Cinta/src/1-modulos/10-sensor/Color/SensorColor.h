/*
 * SensorColor.h
 *
 *  Created on: 21 ago 2026
 *      Author: martina
 */

#ifndef _SENSOR_COLOR_SENSORCOLOR_H_
#define _SENSOR_COLOR_SENSORCOLOR_H_

#include <10-sensor/I2C/I2C.h>
#include "LPC845.h"
#include "Gpio.h"

#define DIR_Sensor 0x5A
#define DIR_ROJO 0x0C
#define DIR_VERDE 0x0D
#define DIR_AZUL 0x0E
#define DIR_CONFIG 0x10
#define UMBRALM 600
#define UMBRALm 200



class SensorColor {
private:
	I2C Comunicacion;
	typedef struct{
			uint8_t ROJO;
			uint8_t VERDE;
			uint8_t AZUL;
		}Color;
public:
	enum{
		NADA,RED,GREEN,BLUE
	};
	SensorColor(uint8_t pines[],uint8_t puertos[]);
	uint8_t Obtener_color(void);
	void White_calibration(void);
	uint8_t SinObjeto( Color Resultado);
	void SetlED(uint8_t Intensidad);
	virtual ~SensorColor();
};


#endif /* 1_MODULOS_SENSOR_COLOR_SENSORCOLOR_H_ */
