src/1-modulos/10-sensor/Color/SensorColor.o \
 src/1-modulos/10-sensor/Color/SensorColor.d: \
 ../src/1-modulos/10-sensor/Color/SensorColor.cpp \
 ../src/1-modulos/10-sensor/Color/SensorColor.h \
 /home/martina/Documentos/facultad/info2/Cinta/Cinta/src/1-modulos/10-sensor/I2C/I2C.h \
 /home/martina/Documentos/facultad/info2/Cinta/Cinta/src/2-drivers/LPC845.h \
 /home/martina/Documentos/facultad/info2/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/info2/Cinta/Cinta/src/2-drivers/swm.h \
 /home/martina/Documentos/facultad/info2/Cinta/Cinta/src/1-modulos/02-gpio/Gpio.h \
 /home/martina/Documentos/facultad/info2/Cinta/Cinta/src/1-modulos/01-pin/in/Inputs.h \
 /home/martina/Documentos/facultad/info2/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/info2/Cinta/Cinta/src/1-modulos/01-pin/out/Outputs.h
../src/1-modulos/10-sensor/Color/SensorColor.h:
/home/martina/Documentos/facultad/info2/Cinta/Cinta/src/1-modulos/10-sensor/I2C/I2C.h:
/home/martina/Documentos/facultad/info2/Cinta/Cinta/src/2-drivers/LPC845.h:
/home/martina/Documentos/facultad/info2/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/info2/Cinta/Cinta/src/2-drivers/swm.h:
/home/martina/Documentos/facultad/info2/Cinta/Cinta/src/1-modulos/02-gpio/Gpio.h:
/home/martina/Documentos/facultad/info2/Cinta/Cinta/src/1-modulos/01-pin/in/Inputs.h:
/home/martina/Documentos/facultad/info2/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/info2/Cinta/Cinta/src/1-modulos/01-pin/out/Outputs.h:
