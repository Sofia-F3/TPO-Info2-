src/1-modulos/05-timer/Timer.o src/1-modulos/05-timer/Timer.d: \
 ../src/1-modulos/05-timer/Timer.cpp \
 ../src/1-modulos/05-timer/../05-timer/Timer.h \
 ../src/1-modulos/05-timer/../05-timer/../04-PerifericosTemporizados/perifericotemporizado.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h
../src/1-modulos/05-timer/../05-timer/Timer.h:
../src/1-modulos/05-timer/../05-timer/../04-PerifericosTemporizados/perifericotemporizado.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
