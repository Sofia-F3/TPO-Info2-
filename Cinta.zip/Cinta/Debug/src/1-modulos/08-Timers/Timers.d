src/1-modulos/08-Timers/Timers.o src/1-modulos/08-Timers/Timers.d: \
 ../src/1-modulos/08-Timers/Timers.cpp \
 ../src/1-modulos/08-Timers/Timers.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/05-timer/Timer.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/05-timer/../04-PerifericosTemporizados/perifericotemporizado.h
../src/1-modulos/08-Timers/Timers.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/05-timer/Timer.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/05-timer/../04-PerifericosTemporizados/perifericotemporizado.h:
