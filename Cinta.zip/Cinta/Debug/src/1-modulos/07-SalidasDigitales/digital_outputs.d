src/1-modulos/07-SalidasDigitales/digital_outputs.o \
 src/1-modulos/07-SalidasDigitales/digital_outputs.d: \
 ../src/1-modulos/07-SalidasDigitales/digital_outputs.cpp \
 ../src/1-modulos/07-SalidasDigitales/../07-SalidasDigitales/digital_outputs.h \
 ../src/1-modulos/07-SalidasDigitales/../07-SalidasDigitales/../04-PerifericosTemporizados/perifericotemporizado.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/systick/systick.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/02-gpio/Gpio.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/in/Inputs.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/out/Outputs.h
../src/1-modulos/07-SalidasDigitales/../07-SalidasDigitales/digital_outputs.h:
../src/1-modulos/07-SalidasDigitales/../07-SalidasDigitales/../04-PerifericosTemporizados/perifericotemporizado.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/systick/systick.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/02-gpio/Gpio.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/in/Inputs.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/out/Outputs.h:
