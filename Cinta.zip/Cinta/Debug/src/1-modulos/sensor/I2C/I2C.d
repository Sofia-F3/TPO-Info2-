src/1-modulos/sensor/I2C/I2C.o src/1-modulos/sensor/I2C/I2C.d: \
 ../src/1-modulos/sensor/I2C/I2C.cpp \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/sensor/I2C/I2C.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/swm.h
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/sensor/I2C/I2C.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/swm.h:
