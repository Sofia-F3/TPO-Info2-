src/1-modulos/03-intext/intext.o src/1-modulos/03-intext/intext.d: \
 ../src/1-modulos/03-intext/intext.cpp \
 ../src/1-modulos/03-intext/intext.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h
../src/1-modulos/03-intext/intext.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
