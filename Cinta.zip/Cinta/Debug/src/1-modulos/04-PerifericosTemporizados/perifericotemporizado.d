src/1-modulos/04-PerifericosTemporizados/perifericotemporizado.o \
 src/1-modulos/04-PerifericosTemporizados/perifericotemporizado.d: \
 ../src/1-modulos/04-PerifericosTemporizados/perifericotemporizado.cpp \
 ../src/1-modulos/04-PerifericosTemporizados/../04-PerifericosTemporizados/perifericotemporizado.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/systick/systick.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h
../src/1-modulos/04-PerifericosTemporizados/../04-PerifericosTemporizados/perifericotemporizado.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/systick/systick.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
