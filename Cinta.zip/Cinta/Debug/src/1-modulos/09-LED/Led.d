src/1-modulos/09-LED/Led.o src/1-modulos/09-LED/Led.d: \
 ../src/1-modulos/09-LED/Led.cpp ../src/1-modulos/09-LED/Led.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/02-gpio/Gpio.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/in/Inputs.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/out/Outputs.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/04-PerifericosTemporizados/perifericotemporizado.h
../src/1-modulos/09-LED/Led.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/02-gpio/Gpio.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/in/Inputs.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/out/Outputs.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/04-PerifericosTemporizados/perifericotemporizado.h:
