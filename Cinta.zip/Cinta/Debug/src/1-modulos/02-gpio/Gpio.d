src/1-modulos/02-gpio/Gpio.o src/1-modulos/02-gpio/Gpio.d: \
 ../src/1-modulos/02-gpio/Gpio.cpp ../src/1-modulos/02-gpio/Gpio.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/in/Inputs.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/out/Outputs.h
../src/1-modulos/02-gpio/Gpio.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/in/Inputs.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/out/Outputs.h:
