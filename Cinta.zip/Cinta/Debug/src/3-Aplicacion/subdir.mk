################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../src/3-Aplicacion/aplicacion.cpp \
../src/3-Aplicacion/inicializarInfotronic.cpp \
../src/3-Aplicacion/main.cpp 

CPP_DEPS += \
./src/3-Aplicacion/aplicacion.d \
./src/3-Aplicacion/inicializarInfotronic.d \
./src/3-Aplicacion/main.d 

OBJS += \
./src/3-Aplicacion/aplicacion.o \
./src/3-Aplicacion/inicializarInfotronic.o \
./src/3-Aplicacion/main.o 


# Each subdirectory must supply rules for building sources it contributes
src/3-Aplicacion/%.o: ../src/3-Aplicacion/%.cpp src/3-Aplicacion/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C++ Compiler'
	arm-none-eabi-c++ -DDEBUG -D__CODE_RED -D__NEWLIB__ -DCORE_M0PLUS -D__MTB_BUFFER_SIZE=256 -D__USE_ROMDIVIDE -DCPP_USE_HEAP -D__LPC84X__ -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/3-Aplicacion" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/02-gpio" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/in" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/out" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/systick" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/04-PerifericosTemporizados" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/05-timer" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/06-EntradasDigitales" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/07-SalidasDigitales" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/03-intext" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/08-Timers" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/09-LED" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/10-sensor/Color" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/10-sensor/I2C" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -fmessage-length=0 -fno-builtin -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m0 -mthumb -fstack-usage -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-src-2f-3-2d-Aplicacion

clean-src-2f-3-2d-Aplicacion:
	-$(RM) ./src/3-Aplicacion/aplicacion.d ./src/3-Aplicacion/aplicacion.o ./src/3-Aplicacion/inicializarInfotronic.d ./src/3-Aplicacion/inicializarInfotronic.o ./src/3-Aplicacion/main.d ./src/3-Aplicacion/main.o

.PHONY: clean-src-2f-3-2d-Aplicacion

