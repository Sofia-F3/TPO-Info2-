src/3-Aplicacion/main.o src/3-Aplicacion/main.d: \
 ../src/3-Aplicacion/main.cpp ../src/3-Aplicacion/inicializarInfotronic.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/05-timer/Timer.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/05-timer/../04-PerifericosTemporizados/perifericotemporizado.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/06-EntradasDigitales/digital_inputs.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/04-PerifericosTemporizados/perifericotemporizado.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/systick/systick.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/02-gpio/Gpio.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/in/Inputs.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/out/Outputs.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/07-SalidasDigitales/digital_outputs.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/07-SalidasDigitales/../04-PerifericosTemporizados/perifericotemporizado.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/dr_pll.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/03-intext/intext.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/08-Timers/Timers.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/09-LED/Led.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/10-sensor/Color/SensorColor.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/10-sensor/I2C/I2C.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/swm.h
../src/3-Aplicacion/inicializarInfotronic.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/05-timer/Timer.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/05-timer/../04-PerifericosTemporizados/perifericotemporizado.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/06-EntradasDigitales/digital_inputs.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/04-PerifericosTemporizados/perifericotemporizado.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/systick/systick.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/02-gpio/Gpio.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/in/Inputs.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/out/Outputs.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/07-SalidasDigitales/digital_outputs.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/07-SalidasDigitales/../04-PerifericosTemporizados/perifericotemporizado.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/dr_pll.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/03-intext/intext.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/08-Timers/Timers.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/09-LED/Led.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/10-sensor/Color/SensorColor.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/10-sensor/I2C/I2C.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/swm.h:
