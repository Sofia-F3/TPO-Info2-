src/2-drivers/dr_pll.o src/2-drivers/dr_pll.d: \
 ../src/2-drivers/dr_pll.cpp ../src/2-drivers/dr_pll.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h
../src/2-drivers/dr_pll.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
