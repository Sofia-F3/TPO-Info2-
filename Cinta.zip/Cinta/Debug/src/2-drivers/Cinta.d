src/2-drivers/Cinta.o src/2-drivers/Cinta.d: ../src/2-drivers/Cinta.cpp
