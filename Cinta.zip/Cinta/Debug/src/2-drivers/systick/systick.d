src/2-drivers/systick/systick.o src/2-drivers/systick/systick.d: \
 ../src/2-drivers/systick/systick.cpp ../src/2-drivers/systick/systick.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h \
 /home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h
../src/2-drivers/systick/systick.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/LPC845.h:
/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/tipos.h:
