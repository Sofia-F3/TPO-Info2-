src/2-drivers/cr_startup_lpc84x.o src/2-drivers/cr_startup_lpc84x.d: \
 ../src/2-drivers/cr_startup_lpc84x.cpp
