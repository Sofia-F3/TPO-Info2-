################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../src/2-drivers/cr_cpp_config.cpp \
../src/2-drivers/cr_startup_lpc84x.cpp \
../src/2-drivers/dr_pll.cpp \
../src/2-drivers/swm.cpp 

C_SRCS += \
../src/2-drivers/crp.c \
../src/2-drivers/mtb.c 

S_SRCS += \
../src/2-drivers/aeabi_romdiv_patch.s 

CPP_DEPS += \
./src/2-drivers/cr_cpp_config.d \
./src/2-drivers/cr_startup_lpc84x.d \
./src/2-drivers/dr_pll.d \
./src/2-drivers/swm.d 

C_DEPS += \
./src/2-drivers/crp.d \
./src/2-drivers/mtb.d 

OBJS += \
./src/2-drivers/aeabi_romdiv_patch.o \
./src/2-drivers/cr_cpp_config.o \
./src/2-drivers/cr_startup_lpc84x.o \
./src/2-drivers/crp.o \
./src/2-drivers/dr_pll.o \
./src/2-drivers/mtb.o \
./src/2-drivers/swm.o 


# Each subdirectory must supply rules for building sources it contributes
src/2-drivers/%.o: ../src/2-drivers/%.s src/2-drivers/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU Assembler'
	arm-none-eabi-gcc -c -x assembler-with-cpp -D__NEWLIB__ -DDEBUG -D__CODE_RED -DCORE_M0PLUS -D__USE_ROMDIVIDE -D__LPC84X__ -g3 -gdwarf-4 -mcpu=cortex-m0 -mthumb -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

src/2-drivers/%.o: ../src/2-drivers/%.cpp src/2-drivers/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C++ Compiler'
	arm-none-eabi-c++ -DDEBUG -D__CODE_RED -D__NEWLIB__ -DCORE_M0PLUS -D__MTB_BUFFER_SIZE=256 -D__USE_ROMDIVIDE -DCPP_USE_HEAP -D__LPC84X__ -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/3-Aplicacion" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/02-gpio" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/in" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/01-pin/out" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/2-drivers/systick" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/04-PerifericosTemporizados" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/05-timer" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/06-EntradasDigitales" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/07-SalidasDigitales" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/03-intext" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/08-Timers" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/09-LED" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/10-sensor/Color" -I"/home/martina/Documentos/facultad/Cinta/Cinta/src/1-modulos/10-sensor/I2C" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -fmessage-length=0 -fno-builtin -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m0 -mthumb -fstack-usage -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

src/2-drivers/%.o: ../src/2-drivers/%.c src/2-drivers/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -DDEBUG -D__CODE_RED -D__NEWLIB__ -DCORE_M0PLUS -D__MTB_BUFFER_SIZE=256 -D__USE_ROMDIVIDE -DCPP_USE_HEAP -D__LPC84X__ -O0 -fno-common -g3 -gdwarf-4 -Wall -c -fmessage-length=0 -fno-builtin -ffunction-sections -fdata-sections -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m0 -mthumb -fstack-usage -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-src-2f-2-2d-drivers

clean-src-2f-2-2d-drivers:
	-$(RM) ./src/2-drivers/aeabi_romdiv_patch.o ./src/2-drivers/cr_cpp_config.d ./src/2-drivers/cr_cpp_config.o ./src/2-drivers/cr_startup_lpc84x.d ./src/2-drivers/cr_startup_lpc84x.o ./src/2-drivers/crp.d ./src/2-drivers/crp.o ./src/2-drivers/dr_pll.d ./src/2-drivers/dr_pll.o ./src/2-drivers/mtb.d ./src/2-drivers/mtb.o ./src/2-drivers/swm.d ./src/2-drivers/swm.o

.PHONY: clean-src-2f-2-2d-drivers

