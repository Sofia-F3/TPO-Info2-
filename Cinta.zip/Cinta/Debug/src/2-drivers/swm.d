src/2-drivers/swm.o src/2-drivers/swm.d: ../src/2-drivers/swm.cpp \
 ../src/2-drivers/swm.h ../src/2-drivers/tipos.h
../src/2-drivers/swm.h:
../src/2-drivers/tipos.h:
