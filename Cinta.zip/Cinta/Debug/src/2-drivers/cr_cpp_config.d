src/2-drivers/cr_cpp_config.o src/2-drivers/cr_cpp_config.d: \
 ../src/2-drivers/cr_cpp_config.cpp
